//
//  ViewController.swift
//  splashScreen
//
//  Created by Krishna Bhargav on 12/12/18.
//  Copyright © 2018 mapprr. All rights reserved.
//

import UIKit

class ViewController : UIViewController {

    @IBOutlet weak var image1: UIImageView!
    
    @IBOutlet weak var animated2: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
          logo()
        }
    
    
      func logo(){
        
            UIView.animate(withDuration: 1.0 , animations: {
                self.image1.frame.origin.y -= 150
            
            })
        
            if image1.animationDuration == 1.0 {
                
    
            print("nothing")

            } else {
               

                 ani()
        }
    
      }
       func  ani(){

        
         animated2?.loadGif(name: "loading-animation")
        UIView.animate(withDuration: 1.0, animations: {
                       self.animated2?.frame.origin.y = 30
        })
      
        }
    }
    


    
   
    
    
    





